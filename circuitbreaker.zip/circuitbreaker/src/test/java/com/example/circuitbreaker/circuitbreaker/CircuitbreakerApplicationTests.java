package com.example.circuitbreaker.circuitbreaker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircuitbreakerApplicationTests {

	@Test
	void contextLoads() {
	}

}
