package com.springjpa.springjpa;

import java.sql.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.springjpa.model.Address;
import com.springjpa.model.Department;
import com.springjpa.model.Employee;
import com.springjpa.model.Skill;
import com.springjpa.model.User;
import com.springjpa.service.DepartmentService;
import com.springjpa.service.EmployeeService;
import com.springjpa.service.SkillService;
import com.springjpa.service.UserService;

@SpringBootApplication
@ComponentScan({ "com*" })
@EnableJpaRepositories(basePackages = "com.springjpa.dao")
@EntityScan({ "com.springjpa.model" })
public class SpringjpaApplication {
	private static final Logger LOGGER = LoggerFactory.getLogger("SpringjpaApplication");

	@Autowired
	public static EmployeeService employeeService;
	@Autowired
	public static DepartmentService departmentService;
	@Autowired
	public static SkillService skillService;
	@Autowired
	public static UserService userService;

	public static void addDepartment() {
		Department d = new Department();
		d.setId(20);
		d.setName("Admin");
		departmentService.saveDepartment(d);
	}

	public static void addEmployee() {

		Employee e = new Employee();
		e.setId(1003);
		e.setName("Sai");
		e.setPermanent(true);
		e.setSalary(450000);
		e.setDate_of_birth(Date.valueOf("1995-01-01"));
		Department d = departmentService.getDepartment(30);
		e.setDepartment(d);
		employeeService.saveEmployee(e);

	}

	public static void getEmployees() {
		List<Employee> empList = employeeService.fetchEmployees();
		empList.forEach(e -> System.out.println(e));

	}

	public static void getDepartment() {
		Department d = departmentService.getDepartment(10);
		System.out.println(d);
		Set<Employee> empList = d.getEmployeeList();
		empList.forEach(e -> System.out.println(e));

	}

	public static void addSkill() {
		Skill s = new Skill();
		// s.setId(1);
		s.setName("Hibernate");
		skillService.saveSkill(s);

	}

	public static void addEmployeeSkill() {
		Employee e = employeeService.get(1001);
		Skill s = skillService.getSkill(21);
		Set<Skill> skillList = new HashSet<Skill>();
		skillList.add(s);
		s = skillService.getSkill(22);
		skillList.add(s);
		e.setSkillList(skillList);
		employeeService.saveEmployee(e);

	}

	public static void getEmployeeSkill() {
		Employee e = employeeService.get(1001);
		System.out.println(e);
		Set<Skill> skillList = e.getSkillList();
		skillList.forEach(s -> System.out.println(s));

	}

	public static void addUser() {
		userService.createUserWithAddress();
	}
	
	public static void getUserAndAddress(long id)
	{
		User u=userService.getUser(id);
		System.out.println("User-->Address"+u);
		Address a=userService.getAddress(id);
		System.out.println("Address-->User "+a);
		
	}
	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(SpringjpaApplication.class, args);
		LOGGER.info("Logger initialized*******************************");
		employeeService = context.getBean(EmployeeService.class);
		departmentService = context.getBean(DepartmentService.class);
		skillService = context.getBean(SkillService.class);
		userService = context.getBean(UserService.class);

		//userService.createUserWithAddress();
		
		LOGGER.info("User data inserted ********");

		getUserAndAddress(1);
		LOGGER.info("Fetching User data  ********");
		
		/*
		 * List<Employee> empList=employeeService.getAllPermanentEmployees();
		 * for(Employee e:empList) { System.out.println(e); Set<Skill>
		 * s=e.getSkillList(); s.forEach(obj->System.out.println(obj)); } int
		 * count=employeeService.getEmployeeCount();
		 * System.out.println("Number of temp. employees="+count);
		 */
		addDepartment();
		 addEmployee();
		// addSkill();
		// addEmployeeSkill();
		// getEmployees();
		// getDepartment();
		// getEmployeeSkill();
		// testUpdateEmployee();

		// testAddSkill();
		// testAddSkillToEmployee();
		// testGetEmployeeSkill();
		// testGetAllPermanentEmployees();

	}
}
