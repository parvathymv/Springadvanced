package com.springjpa.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.springjpa.model.Person;
 
@Repository
public interface PersonRepository extends JpaRepository<Person, Long> {
@Modifying
	//update employee set salary=45000 where empid=1001
@Query(value="select * from person_info",nativeQuery = true)
List<Person> fetchAllPersons();

	@Query("update Person set age = :a where id = :pid")
	int updatePersonAge(@Param("a") int age,@Param("pid") long id);
	
	List<Person> findByNameStartingWith(String prefix);
	List<Person> findByNameEndingWith(String suffix);
	List<Person> findByAgeBetween(Integer startAge, Integer endAge);
	List<Person> findByAgeGreaterThan(Integer age);
	List<Person> findAllByOrderByNameAsc();
	
	//List<Person> findByNameContainsOrderByNameAsc(String code);
	//List <Person> findFirst3ByIdOrderByCloseAsc(String name);
	//List<Person> findAllByOrderByNameAsc();
}
