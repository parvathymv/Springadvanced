package com.springjpa.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springjpa.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
}
