package com.springjpa.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springjpa.model.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {
}
