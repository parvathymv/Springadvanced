package com.springjpa.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springjpa.dao.AddressRepository;
import com.springjpa.dao.UserRepository;
import com.springjpa.model.Address;
import com.springjpa.model.User;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private AddressRepository addressRepository;

    public void createUserWithAddress() {
        User user = new User();
        user.setName("Sai");

        Address address = new Address();
        address.setStreet("123 Second Street");
        address.setCity("Chennai");

  user.setAddress(address);

        userRepository.save(user); // Save user (cascades to address)
    }
    public User getUser(long id)
    {
    	User u=null;
    	Optional<User> optional=userRepository.findById(id);
    	if(optional.isPresent())
    	{
    		u=optional.get();
    		
    	}
    	System.out.println("In userservice ="+u);
    	return u;
    }
    
    public Address getAddress(long id)
    {
    	Address u=null;
    	Optional<Address> optional=addressRepository.findById(id);
    	if(optional.isPresent())
    	{
    		u=optional.get();
    		
    	}
    	//System.out.println("In userservice ="+u);
    	return u;
    }
    
}

