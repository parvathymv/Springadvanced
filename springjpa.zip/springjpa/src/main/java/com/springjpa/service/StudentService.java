package com.springjpa.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springjpa.dao.StudentRepository;
import com.springjpa.model.Student;


@Service
public class StudentService {
@Autowired
StudentRepository studRepo;

	public Student saveStudent(Student s) {
		System.out.println("Repository "+studRepo);
		Student obj=studRepo.save(s);
		System.out.println(obj);
	return obj;

		//return studRepo.save(s);
	}

	public List<Student> getAllStudents()
	{
		
		return studRepo.findAll();
	}
	
	public  Student getStudentById(int rno)
	{
		
		return studRepo.findById(rno).get();
	}
	public List<Student> getStudentsByDepartment(String dept,String name)
	{
		
		return studRepo.getStudentsByDepartment(dept, name);
	}
	public List<Student> getStudentsByDepartment(String dept)
	{
		return studRepo.getStudentsByDepartment(dept);
	}
	@Transactional
	public int updateStudentByName(String dept,String name)
	{
		return studRepo.updateStudentByName(dept, name);
	}
	@Transactional
	public List<Student> fetchStudentByMail(String  mail)
	{
		return studRepo.fetchStudentByMail(mail);
	}
}
